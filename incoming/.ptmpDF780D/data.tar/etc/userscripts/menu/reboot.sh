aplay /sounds/logoff.wav
systemctl reboot
xmessage Click Okay to Force Shut Down
kill -9 -1
