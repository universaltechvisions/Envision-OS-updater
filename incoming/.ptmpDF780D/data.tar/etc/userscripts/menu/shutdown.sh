aplay /sounds/logoff.wav
systemctl poweroff
xmessage Click Okay to Force Shut Down
kill -9 -1
