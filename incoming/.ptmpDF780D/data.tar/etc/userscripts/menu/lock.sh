xscreensaver-command -lock
