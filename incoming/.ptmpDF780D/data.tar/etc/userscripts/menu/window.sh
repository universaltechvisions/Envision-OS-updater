#!/bin/bash
cd '/etc/userscripts/menu/' && ./Menu &
sleep 0.18 && bash /etc/userscripts/menu/window1.sh &
