pcmanfm menu://applications/
