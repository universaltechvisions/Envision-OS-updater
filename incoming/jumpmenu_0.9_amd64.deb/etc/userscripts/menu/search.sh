pcmanfm -f
