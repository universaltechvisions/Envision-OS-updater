#!/bin/bash
#cd '/etc/userscripts/menu/' && 
./Menu & sleep 0.18 && bash window1.sh &
