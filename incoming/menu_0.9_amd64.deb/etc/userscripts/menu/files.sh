pcmanfm ~/
