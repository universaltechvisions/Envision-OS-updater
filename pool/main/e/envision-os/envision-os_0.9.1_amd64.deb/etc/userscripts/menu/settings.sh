pcmanfm menu://applications/Settings

